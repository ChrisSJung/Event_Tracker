package utility;

public interface Savable {
    /**
     * @return A unique ID for the Savable.
     */
    String getID();
}
