package utility;

public interface Viewable {
}
