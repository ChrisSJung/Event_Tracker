import controllers.SystemController;

public class PhaseTwoMain {
    public static void main(String[] args) {
        SystemController controller = new SystemController();
        controller.run();
    }
}
