package controllers;

/**
 * Exception which is thrown if the user chooses the exit their current menu.
 */
public class ExitException extends Exception {}
