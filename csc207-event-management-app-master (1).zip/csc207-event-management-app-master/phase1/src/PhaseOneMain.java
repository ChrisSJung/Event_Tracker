import controllers.SystemController;

public class PhaseOneMain {
    public static void main(String[] args) {
        SystemController controller = new SystemController();
        controller.run();
    }
}
